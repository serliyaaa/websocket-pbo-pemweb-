const WebSocket = require('ws');
const db = require('./db'); // Koneksi ke MySQL
const { checkForKeyword } = require('./utils'); // Helper untuk memeriksa keyword

// Inisialisasi WebSocket server
const wss = new WebSocket.Server({ port: 8080 }, () => {
    console.log('WebSocket Server running on ws://localhost:8080');
});

// Saat client terhubung
wss.on('connection', (ws) => {
    console.log('Client connected');

    // Kirim data real-time dari database ke client
    const sendDataToClient = () => {
        db.query('SELECT * FROM messages', (err, results) => {
            if (err) return console.error(err);

            // Kirim data ke client
            ws.send(JSON.stringify({ type: 'data', data: results }));

            // Periksa jika ada keyword tertentu
            const keywordFound = checkForKeyword(results, 'urgent'); // Contoh keyword "urgent"
            if (keywordFound) {
                ws.send(JSON.stringify({ type: 'notification', message: 'Keyword found: urgent!' }));
            }
        });
    };

    // Kirim data real-time setiap 5 detik
    const interval = setInterval(sendDataToClient, 5000);

    // Tutup koneksi
    ws.on('close', () => {
        clearInterval(interval);
        console.log('Client disconnected');
    });
});
