module.exports = {
    db: {
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'websocket_db'
    }
};
